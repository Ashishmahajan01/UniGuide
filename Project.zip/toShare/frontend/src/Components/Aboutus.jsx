import React from 'react';
import "../CSS/Aboutus.css";
import image1 from '../Images/college1.jpg'
import image2 from '../Images/college.jpg'
import image3 from '../Images/college.jpg'
import image4 from '../Images/college.jpg'
const Aboutus = () => { 

    return (
   <div className="App">    
      <header className="hero">
        <img src={image1} alt="Header Image" />
      </header>

      <section className="education-content">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
aliquip ex ea commodo consequat.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </section>

      <section className="creators">
        <div className="creator">
            <img src={ image1} alt="Creator 1" />
          <p>Name 1</p>
        </div>
        <div className="creator">
          <img src={image2} alt="Creator 2" />
          <p>Name 2</p>
        </div>
        <div className="creator">
          <img src={image3} alt="Creator 3" />
          <p>Name 3</p>
        </div>
        <div className="creator">
          <img src={image4} alt="Creator 4" />
          <p>Name 4</p>
        </div>
      </section>
    </div>

    )
}

export default Aboutus;