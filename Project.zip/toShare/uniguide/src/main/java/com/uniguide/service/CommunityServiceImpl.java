package com.uniguide.service;

import org.springframework.stereotype.Service;

@Service
public class CommunityServiceImpl implements CommunityService {

}
