package com.uniguide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniguideApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniguideApplication.class, args);
	}

}
