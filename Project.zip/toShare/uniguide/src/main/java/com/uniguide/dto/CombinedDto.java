package com.uniguide.dto;

import com.uniguide.beans.Branch;
import com.uniguide.beans.College;
import com.uniguide.beans.IntakeVacancy;
import com.uniguide.beans.Stream;
import com.uniguide.beans.University;

public class CombinedDto {
	private College college;
	private University university;
	private Stream stream;
	private Branch branch;
	//private IntakeVacancy intakeVacancy;

}
