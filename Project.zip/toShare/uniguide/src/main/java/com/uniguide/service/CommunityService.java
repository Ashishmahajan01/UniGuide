package com.uniguide.service;

public interface CommunityService {

}
